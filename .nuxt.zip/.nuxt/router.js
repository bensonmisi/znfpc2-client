import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _58b7d871 = () => interopDefault(import('..\\pages\\administrators.vue' /* webpackChunkName: "pages/administrators" */))
const _57436536 = () => interopDefault(import('..\\pages\\ChangePassword.vue' /* webpackChunkName: "pages/ChangePassword" */))
const _60a0a1b9 = () => interopDefault(import('..\\pages\\dashboard.vue' /* webpackChunkName: "pages/dashboard" */))
const _34e65382 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _2b7afae4 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _7b7ad524 = () => interopDefault(import('..\\pages\\Profile.vue' /* webpackChunkName: "pages/Profile" */))
const _457d107c = () => interopDefault(import('..\\pages\\Roles.vue' /* webpackChunkName: "pages/Roles" */))
const _28ba6dc6 = () => interopDefault(import('..\\pages\\systemmodules.vue' /* webpackChunkName: "pages/systemmodules" */))
const _5f50af29 = () => interopDefault(import('..\\pages\\resetPassword\\_token.vue' /* webpackChunkName: "pages/resetPassword/_token" */))
const _209adf77 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/administrators",
    component: _58b7d871,
    name: "administrators"
  }, {
    path: "/ChangePassword",
    component: _57436536,
    name: "ChangePassword"
  }, {
    path: "/dashboard",
    component: _60a0a1b9,
    name: "dashboard"
  }, {
    path: "/inspire",
    component: _34e65382,
    name: "inspire"
  }, {
    path: "/login",
    component: _2b7afae4,
    name: "login"
  }, {
    path: "/Profile",
    component: _7b7ad524,
    name: "Profile"
  }, {
    path: "/Roles",
    component: _457d107c,
    name: "Roles"
  }, {
    path: "/systemmodules",
    component: _28ba6dc6,
    name: "systemmodules"
  }, {
    path: "/resetPassword/:token?",
    component: _5f50af29,
    name: "resetPassword-token"
  }, {
    path: "/",
    component: _209adf77,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
