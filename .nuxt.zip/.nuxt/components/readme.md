# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<SideBar>` | `<side-bar>` (components/SideBar.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)
- `<AdministratorAdd>` | `<administrator-add>` (components/administrator/add.vue)
- `<AdministratorEdit>` | `<administrator-edit>` (components/administrator/edit.vue)
- `<AdministratorReset>` | `<administrator-reset>` (components/administrator/reset.vue)
- `<RoleAdd>` | `<role-add>` (components/role/add.vue)
- `<RoleDelete>` | `<role-delete>` (components/role/delete.vue)
- `<RoleEdit>` | `<role-edit>` (components/role/edit.vue)
- `<PermissionsAdd>` | `<permissions-add>` (components/permissions/add.vue)
- `<PermissionsDelete>` | `<permissions-delete>` (components/permissions/delete.vue)
- `<PermissionsEdit>` | `<permissions-edit>` (components/permissions/edit.vue)
- `<PermissionsView>` | `<permissions-view>` (components/permissions/view.vue)
- `<RolemodulesAssign>` | `<rolemodules-assign>` (components/rolemodules/assign.vue)
- `<RolemodulesUnassign>` | `<rolemodules-unassign>` (components/rolemodules/unassign.vue)
- `<RolemodulesView>` | `<rolemodules-view>` (components/rolemodules/view.vue)
- `<RolepermissionsAssign>` | `<rolepermissions-assign>` (components/rolepermissions/assign.vue)
- `<RolepermissionsUnassign>` | `<rolepermissions-unassign>` (components/rolepermissions/unassign.vue)
- `<RolepermissionsView>` | `<rolepermissions-view>` (components/rolepermissions/view.vue)
- `<RolesubmodulesAssign>` | `<rolesubmodules-assign>` (components/rolesubmodules/assign.vue)
- `<RolesubmodulesUnassign>` | `<rolesubmodules-unassign>` (components/rolesubmodules/unassign.vue)
- `<RolesubmodulesView>` | `<rolesubmodules-view>` (components/rolesubmodules/view.vue)
- `<SubmodulesAdd>` | `<submodules-add>` (components/submodules/add.vue)
- `<SubmodulesDelete>` | `<submodules-delete>` (components/submodules/delete.vue)
- `<SubmodulesEdit>` | `<submodules-edit>` (components/submodules/edit.vue)
- `<SubmodulesView>` | `<submodules-view>` (components/submodules/view.vue)
- `<SystemmodulesAdd>` | `<systemmodules-add>` (components/systemmodules/add.vue)
- `<SystemmodulesDelete>` | `<systemmodules-delete>` (components/systemmodules/delete.vue)
- `<SystemmodulesEdit>` | `<systemmodules-edit>` (components/systemmodules/edit.vue)
