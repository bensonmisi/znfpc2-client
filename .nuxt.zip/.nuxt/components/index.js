export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const SideBar = () => import('../..\\components\\SideBar.vue' /* webpackChunkName: "components/side-bar" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const VuetifyLogo = () => import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c))
export const AdministratorAdd = () => import('../..\\components\\administrator\\add.vue' /* webpackChunkName: "components/administrator-add" */).then(c => wrapFunctional(c.default || c))
export const AdministratorEdit = () => import('../..\\components\\administrator\\edit.vue' /* webpackChunkName: "components/administrator-edit" */).then(c => wrapFunctional(c.default || c))
export const AdministratorReset = () => import('../..\\components\\administrator\\reset.vue' /* webpackChunkName: "components/administrator-reset" */).then(c => wrapFunctional(c.default || c))
export const RoleAdd = () => import('../..\\components\\role\\add.vue' /* webpackChunkName: "components/role-add" */).then(c => wrapFunctional(c.default || c))
export const RoleDelete = () => import('../..\\components\\role\\delete.vue' /* webpackChunkName: "components/role-delete" */).then(c => wrapFunctional(c.default || c))
export const RoleEdit = () => import('../..\\components\\role\\edit.vue' /* webpackChunkName: "components/role-edit" */).then(c => wrapFunctional(c.default || c))
export const PermissionsAdd = () => import('../..\\components\\permissions\\add.vue' /* webpackChunkName: "components/permissions-add" */).then(c => wrapFunctional(c.default || c))
export const PermissionsDelete = () => import('../..\\components\\permissions\\delete.vue' /* webpackChunkName: "components/permissions-delete" */).then(c => wrapFunctional(c.default || c))
export const PermissionsEdit = () => import('../..\\components\\permissions\\edit.vue' /* webpackChunkName: "components/permissions-edit" */).then(c => wrapFunctional(c.default || c))
export const PermissionsView = () => import('../..\\components\\permissions\\view.vue' /* webpackChunkName: "components/permissions-view" */).then(c => wrapFunctional(c.default || c))
export const RolemodulesAssign = () => import('../..\\components\\rolemodules\\assign.vue' /* webpackChunkName: "components/rolemodules-assign" */).then(c => wrapFunctional(c.default || c))
export const RolemodulesUnassign = () => import('../..\\components\\rolemodules\\unassign.vue' /* webpackChunkName: "components/rolemodules-unassign" */).then(c => wrapFunctional(c.default || c))
export const RolemodulesView = () => import('../..\\components\\rolemodules\\view.vue' /* webpackChunkName: "components/rolemodules-view" */).then(c => wrapFunctional(c.default || c))
export const RolepermissionsAssign = () => import('../..\\components\\rolepermissions\\assign.vue' /* webpackChunkName: "components/rolepermissions-assign" */).then(c => wrapFunctional(c.default || c))
export const RolepermissionsUnassign = () => import('../..\\components\\rolepermissions\\unassign.vue' /* webpackChunkName: "components/rolepermissions-unassign" */).then(c => wrapFunctional(c.default || c))
export const RolepermissionsView = () => import('../..\\components\\rolepermissions\\view.vue' /* webpackChunkName: "components/rolepermissions-view" */).then(c => wrapFunctional(c.default || c))
export const RolesubmodulesAssign = () => import('../..\\components\\rolesubmodules\\assign.vue' /* webpackChunkName: "components/rolesubmodules-assign" */).then(c => wrapFunctional(c.default || c))
export const RolesubmodulesUnassign = () => import('../..\\components\\rolesubmodules\\unassign.vue' /* webpackChunkName: "components/rolesubmodules-unassign" */).then(c => wrapFunctional(c.default || c))
export const RolesubmodulesView = () => import('../..\\components\\rolesubmodules\\view.vue' /* webpackChunkName: "components/rolesubmodules-view" */).then(c => wrapFunctional(c.default || c))
export const SubmodulesAdd = () => import('../..\\components\\submodules\\add.vue' /* webpackChunkName: "components/submodules-add" */).then(c => wrapFunctional(c.default || c))
export const SubmodulesDelete = () => import('../..\\components\\submodules\\delete.vue' /* webpackChunkName: "components/submodules-delete" */).then(c => wrapFunctional(c.default || c))
export const SubmodulesEdit = () => import('../..\\components\\submodules\\edit.vue' /* webpackChunkName: "components/submodules-edit" */).then(c => wrapFunctional(c.default || c))
export const SubmodulesView = () => import('../..\\components\\submodules\\view.vue' /* webpackChunkName: "components/submodules-view" */).then(c => wrapFunctional(c.default || c))
export const SystemmodulesAdd = () => import('../..\\components\\systemmodules\\add.vue' /* webpackChunkName: "components/systemmodules-add" */).then(c => wrapFunctional(c.default || c))
export const SystemmodulesDelete = () => import('../..\\components\\systemmodules\\delete.vue' /* webpackChunkName: "components/systemmodules-delete" */).then(c => wrapFunctional(c.default || c))
export const SystemmodulesEdit = () => import('../..\\components\\systemmodules\\edit.vue' /* webpackChunkName: "components/systemmodules-edit" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
